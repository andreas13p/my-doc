CREATE DATABASE `myDB` ;
USE `myDB`;


CREATE TABLE `admin` (
  `id` int NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ;

